export const warlockLightningDragon = {
  LORD_OF_THUNDER
};

/**
 * Lord of Thunder: Chaos.
 * Choose between the 5 options, update the item, then use it.
 */
async function LORD_OF_THUNDER(item, speaker, actor, token, character, event, args) {
  /**
   * Options:
   * - Con save, stunned until end of THEIR next turn.
   * - Str save, pushed 15ft (further) away.
   * - Str save, pulled 15ft closer (if at least 5 feet away).
   * - Dex save, prone.
   * - No save, cannot take reactions, deafened until start of THEIR next turn.
   */

  const buttons = {
    stun: {label: "Stun", callback},
    push: {label: "Push", callback},
    pull: {label: "Pull", callback},
    prone: {label: "Prone", callback},
    deaf: {label: "Deafen", callback}
  };

  return new Dialog({buttons}).render(true);

  async function callback(html, event) {
    const option = event.currentTarget.dataset.button;
    const target = game.user.targets.first();

    if (option === "stun") {
      await _updateSave("con");
      await _createEffect("stun");
    } else if (option === "push") {
      await _updateSave("str");
      await _createEffect();
      await _pushTarget(target);
    } else if (option === "pull") {
      await _updateSave("str");
      await _createEffect();
      await _pullTarget(target);
    } else if (option === "prone") {
      await _updateSave("dex");
      await _createEffect("prone");
    } else if (option === "deaf") {
      await _updateSave(null);
      await _createEffect("reaction", "deaf");
    }
    return item.use({}, {configureDialog: false});
  }

  async function _createEffect(...ids) {
    if (!ids.length) return item.deleteEmbeddedDocuments("ActiveEffect", [], {deleteAll: true});
    const datas = ids.map(id => CONFIG.statusEffects.find(e => e.id === id));
    await item.deleteEmbeddedDocuments("ActiveEffect", [], {deleteAll: true});
    return item.createEmbeddedDocuments("ActiveEffect", [{
      name: datas.map(d => game.i18n.localize(d.name)).join(" / "),
      statuses: ids,
      changes: datas.flatMap(d => d.changes ?? []),
      description: datas.map(d => d.description || "").join(""),
      icon: datas[0].icon,
      flags: datas.reduce((acc, d) => foundry.utils.mergeObject(acc, d.flags), {}),
      transfer: false
    }]);
  }
  async function _updateSave(type) {
    return item.update({"system.save.type": type});
  }
  async function _pushTarget(target) {}
  async function _pullTarget(target) {}
}